var wasm;
let load_wasm3 = function (url, sysjs_constructor)
{
    let g     = { };
    let sysjs = sysjs_constructor(g);
    const wasm3_import = {
      env: {
        js:         new WebAssembly.Table({ initial: 2, element: "anyfunc" }),
        memory:     new WebAssembly.Memory({ initial: 1, maximum: 32, shared: true }),
        memoryBase: 0,
        memset:     sysjs.memset,
        memmove:    sysjs.memmove,
      }
    };

    WebAssembly.instantiateStreaming(fetch(url), wasm3_import).then(
        function(obj) {
            g.memory = new Uint8Array(obj.instance.exports.memory.buffer);
            wasm     = obj;
        }
    )
}

module.exports.load_wasm3 = load_wasm3;
module.exports.wasm       = wasm;
