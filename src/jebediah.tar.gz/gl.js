var gl;

let resize = function ()
{
  let el = document.getElementById("canvas");
  el.width = window.innerWidth;
  el.height = window.innerHeight;
  gl.viewport(0,0,el.width,el.height);
}

let init_gl = function(id)
{
  console.log("init_gl()");
  let options = { alpha: false };
  let el = document.getElementById(id);
  try { gl = el.getContext("webgl", options) } catch (e) { }
  try { gl = gl || canvas.getContext("experimental-webgl", options); } catch(e) { }
  if (gl == null) {
    console.log("couldn't create GL instance");
    return;
  }
  window.onresize = resize;
  resize();
  gl.clearColor(0.5, 0.5, 0.5, 0);
  gl.clear(gl.COLOR_BUFFER_BIT + gl.DEPTH_BUFFER_BIT);
}

module.exports.gl      = gl;
module.exports.init_gl = init_gl;
