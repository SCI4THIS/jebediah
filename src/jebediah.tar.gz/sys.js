let sysjs = function (g) {

  let memmove = function (i32_1, i32_2, i32_3) {
      let dst = i32_1;
      let src = i32_2;
      let n   = i32_3;

      if (src == dst) {
        return dst;
      }

      if (dst < src) {
        for (let i=0; i<n; i++) {
          g.memory[dst + i] = g.memory[src + i];
        }
      } else {
        for (let i=n; i-->0; ) {
          g.memory[dst + i] = g.memory[src + i];
        }
      }

      return dst;
  };

  let memset = function(i32_1, i32_2, i32_3) {
      let dst = i32_1;
      let val = i32_2;
      let n   = i32_3;
      for (let i=0; i<n; i++) {
        g.memory[dst + i] = val;
      }
      return dst;
  };

  let strlen = function(i32_1) {
      let src = i32_1;
      let i   = 0;
      while (g.memory[src + i] != 0) {
        i++;
      }
      return i;
  };

  let strnlen = function(i32_1, i32_2) {
      let src = i32_1;
      let n   = i32_2;
      let i   = 0;
      while (g.memory[src + i] != 0 && i < n) {
        i++;
      }
      return i;
  };

  return {
      memset:  memset,
      memmove: memmove,
      memcpy:  memmove,
      strlen:  strlen,
      strnlen: strnlen,
  };
}

module.exports.sysjs = sysjs;
